# noUiSlider
_Current version: 3.2.0_

noUiSlider is a little jQuery plugin that allows you to create range sliders.
It fully supports touch, and it is way(!) less bloated than the jQueryUI library.

A full documentation, including examples, is available on the [noUiSlider documentation page](http://refreshless.com/nouislider/).

**Changelog for version 3.2.1:**
_[latest minor release]_

* Fixed an issue when initializing a slider with two handles, both on 100%.

**Changelog for version 3:**
_[current major release]_

* Added responsive design support
* Added Windows Pointer Events support
* Fixed issues
* Reduced file size