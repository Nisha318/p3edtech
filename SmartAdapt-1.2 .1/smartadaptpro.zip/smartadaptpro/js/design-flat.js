(function ($) {
	"use strict";

	jQuery(document).ready(function ($) {

		//Add infield label
		$("label").inFieldLabels();

	});
})(jQuery);