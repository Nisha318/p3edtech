<form role="search" method="get" id="searchform-content" action="<?php echo home_url('/'); ?>">
    <div class="row">


        <input type="text" value="" name="s" class="search-content-input"
               placeholder="<?php _e('Search', 'smartadapt'); ?>">


        <input type="submit" class="searchsubmit-content" value="<?php _e('Search', 'smartadapt'); ?>">

    </div>
</form>